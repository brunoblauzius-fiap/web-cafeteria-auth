def lambda_handler(event, context):
    # Código para gerar o token aqui.
    return {
        'statusCode': 200,
        'body': 'Hello, World!'
    }